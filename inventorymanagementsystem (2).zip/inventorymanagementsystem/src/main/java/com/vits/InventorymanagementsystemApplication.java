package com.vits;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventorymanagementsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventorymanagementsystemApplication.class, args);
	}

}
